
public class Pair {

    public int x, y;
    public Direction d;
    public int mod;

    public Pair(int a, int b, Direction c, int tempmod) {
        x = a;
        y = b;
        d = c;
        mod = tempmod;
    }
}