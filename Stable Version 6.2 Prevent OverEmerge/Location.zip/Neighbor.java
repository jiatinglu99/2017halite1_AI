//A neighbor contains the Direction and its strength
public class Neighbor {
    public Direction direction;
    public int strength;
    
    public Neighbor(Direction d, int s) {
        direction = d;
        strength = s;
    }
}