
public class InitPackage {
    public int myID;
    public GameMap map;
}
