public class Mesage {

    public int x, y;
    public Direction direction;
    public double value;

    public Mesage(int a, int b, Direction c, double tempValue) {
        x = a;
        y = b;
        direction = c;
        value = 1.0*tempValue;
    }
}