
public class Pair {

    public int x, y;
    public Direction d;
    public int mod, need;

    public Pair(int a, int b, Direction c, int tempmod, int need) {
        x = a;
        y = b;
        d = c;
        mod = tempmod;
    }
}