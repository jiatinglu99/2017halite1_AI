
public class Pair {

    public int x, y;
    public Direction d;

    public Pair(int a, int b, Direction c) {
        x = a;
        y = b;
        d = c;
    }
}